package fpstracker.core;

public interface AddSample {
	public void addSample(int sample);
	public void addSample(float sample);
	public void addSample(long sample);
	public void addSample(double sample);
	public void addSample(byte sample);
	public void addSample(short sample);
}
