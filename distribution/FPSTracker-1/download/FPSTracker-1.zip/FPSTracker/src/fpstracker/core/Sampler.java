package fpstracker.core;

import processing.core.PApplet;

public class Sampler extends BaseSampler{
	
	public Sampler() {
	}
	
	public Sampler(PApplet parent, int samplingSize, TrackerType type) {
		super(parent, samplingSize, type);
	}
}
