package fpstracker.ui;

import processing.core.PApplet;

public class UIPanel extends BaseUIPanel{

	public UIPanel(PApplet parent, int width, int height, UI ui) {
		super(parent, width, height, ui);
		// TODO Auto-generated constructor stub
	}

}
